import 'package:flute_music_player/flute_music_player.dart';

class Playlist{

  String name;
  List<Song> songs;

  Playlist(this.name,this.songs);
}